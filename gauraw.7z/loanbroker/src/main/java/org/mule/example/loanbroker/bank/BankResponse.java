package org.mule.example.loanbroker.bank;

public class BankResponse {
	private String desc;
	private String emi;
	private Double roi;
	
	
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getEmi() {
		return emi;
	}
	public void setEmi(String emi) {
		this.emi = emi;
	}
	public Double getRoi() {
		return roi;
	}
	public void setRoi(Double roi) {
		this.roi = roi;
	}
	
	public String toString()
	{
		return "----Desc="+desc+":roi="+roi+":emi="+emi+"------------";
	}
}