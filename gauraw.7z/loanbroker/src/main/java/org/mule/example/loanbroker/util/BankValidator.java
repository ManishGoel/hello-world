package org.mule.example.loanbroker.util;

import java.util.ArrayList;
import java.util.List;
import org.mule.config.i18n.Message;
import org.mule.api.MuleEvent;
import org.mule.extension.validation.api.ValidationResult;
import org.mule.extension.validation.api.Validator;
import org.mule.extension.validation.internal.ImmutableValidationResult;

public class BankValidator implements Validator{

	public BankValidator()
	{}
	
	@Override
	public ValidationResult validate(MuleEvent event) {

		 
		System.out.println("&&& IN VALIDATOR &&&& event="+event);
		List<String> banks = new ArrayList<>();
		banks.add("icici");
		banks.add("sbi");
		banks.add("hdfc");
		banks.add("all");
		
		
		if(!event.getFlowVariable("email").toString().contains("@"))
		{
			//Message message = new Message("EMAIL PAYLOAD EXCEPTION",500,event.getFlowVariable("email"));
			event.getMessage().setPayload("----------EMAIL PAYLOAD EXCEPTION------------------");
			return ImmutableValidationResult.error("-----EMAIL IS NOT CORRECT----");
			
		}	
		
		if(!banks.contains(event.getFlowVariable("bank")))
		{
			event.getMessage().setPayload("----------BANK PAYLOAD EXCEPTION------------------");
			return ImmutableValidationResult.error("-----BANK NAME IS NOT CORRECT----");
			
		}		
		return ImmutableValidationResult.ok();
	}

}
