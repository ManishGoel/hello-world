package org.mule.example.loanbroker.model;

import java.io.Serializable;
import java.util.List;

import org.mule.example.loanbroker.bank.BankResponse;

public class Customer implements Serializable
{
    private static final long serialVersionUID = 4622840173638021051L;
    private String name;
    private Integer ssn;
    private String email;
    private Long salary;
    private String bank;
	private Integer term;
    private Long amount;
    private Long credit_score;
    
    public Customer()
    {
        super();
    }

    public Customer(String name, Integer ssn,Long salary,String bank,String email, Integer term,Long amount)
    {
        this.name = name;
        this.ssn = ssn;
        this.bank = bank;
        this.email = email;
        this.term = term;
        this.amount = amount;
        this.salary = salary;
    }

    
    public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getSalary() {
		return salary;
	}

	public void setSalary(Long salary) {
		this.salary = salary;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Integer getSsn()
    {
        return ssn;
    }

    public void setSsn(Integer ssn)
    {
        this.ssn = ssn;
    }
	
    public void setTerm(Integer term) {
		this.term = term;
	}

    public Integer getTerm() {
 		return term;
 	}

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

	public Long getCredit_score() {
		return credit_score;
	}

	public void setCredit_score(Long credit_score) {
		this.credit_score = credit_score;
	}

}
