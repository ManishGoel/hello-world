package org.mule.example.loanbroker.util;

import java.util.Comparator;

import org.mule.example.loanbroker.bank.BankResponse;

public class MyROIComprator implements Comparator<BankResponse>{
	@Override
    public int compare(BankResponse e1, BankResponse e2) {
        if(e1.getRoi() > e2.getRoi()){
            return 1;
        } else {
            return -1;
        }
    }

}
