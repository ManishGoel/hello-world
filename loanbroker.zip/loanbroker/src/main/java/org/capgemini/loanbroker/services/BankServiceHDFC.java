package org.capgemini.loanbroker.services;

import java.io.Serializable;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/hdfcrequest")
public class BankServiceHDFC implements Serializable {

	/**
     * Serial version
     */
    private static final long serialVersionUID = 4108271137166107769L;
    
    private BankUtility bankUtil = new BankUtility();
    
	private double hdfcInterest = 10.0;
	private int hdfcCreditScore = 600;
	private double emi = 0.0;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ServiceResponse getLoanStatus(@QueryParam("name") String name, @QueryParam("ssn") int ssn, 
			@QueryParam("amount") Long amount, @QueryParam("term") int term, 
			@QueryParam("email") String email, @QueryParam("creditScore") int creditScore) {

		System.out.println("HDFC Request Recieved : Input Parameters are :: Name = " +name+ " ,SSN = " +ssn+ " ,"
				+ "amount = " +amount+ " ,term = " +term+ " ,email = " +email+ " ,creditscore = " +creditScore);
		
		ServiceResponse myResponse = new ServiceResponse();

		myResponse.setName(name);
		myResponse.setSsn(ssn);
		myResponse.setAmount(amount);
		myResponse.setTerm(term);
		myResponse.setEmail(email);
		myResponse.setCreditScore(creditScore);
		
		if (creditScore < hdfcCreditScore) {
			myResponse.setInterest(0.0);
			myResponse.setEMI(0.0);
			myResponse.setStatus("Your are not eligible for loan with HDFC due to low credit score");
		} else {
			emi = bankUtil.calculateEMI(amount, term, hdfcInterest);
			
			myResponse.setInterest(hdfcInterest);
			myResponse.setEMI(emi);
			myResponse.setStatus("Congratulations, your loan can be processed with HDFC");
		}
		
		System.out.println("HDFC Response sent : Input Parameters are :: Name = " +name+ " ,SSN = " +ssn+ " ,"
				+ "amount = " +amount+ " ,term = " +term+ " ,email = " +email+ " ,creditscore = " +creditScore + " ,EMI = " +emi+ " ,interest = " +hdfcInterest);
		
		return myResponse;
	}
}
