package org.capgemini.loanbroker.services;

import java.io.Serializable;

public class BankUtility implements Serializable {

	
    /**
     * Serial version
     */
    private static final long serialVersionUID = 4108271137166107769L;
    
    
	public double calculateEMI(Long amount, int term, double interest) {
		double finalRate = interest/1200;
		double emi = Math.round((amount * finalRate *(Math.pow((1 + finalRate), term)) / ((Math.pow((1 + finalRate), term)) - 1)));
		return emi;
	}
	
}
