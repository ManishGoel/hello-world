package org.capgemini.loanbroker.services;

import java.io.Serializable;

public class BankServiceICICI implements Serializable{

	
    /**
     * Serial version
     */
    private static final long serialVersionUID = 4108271137166107769L;
    
    private BankUtility bankUtil = new BankUtility();
    
	private double iciciInterest = 9.4;
	private int iciciCreditScore = 800;
	private double emi = 0.0;
	
	public ServiceResponse getLoanStatus(String name, int ssn, Long amount, int term, String email, int creditScore) {

		System.out.println("ICICI Request Recieved : Input Parameters are :: Name = " +name+ " ,SSN = " +ssn+ " ,"
				+ "amount = " +amount+ " ,term = " +term+ " ,email = " +email+ " ,creditscore = " +creditScore);
		ServiceResponse myResponse = new ServiceResponse();

		myResponse.setName(name);
		myResponse.setSsn(ssn);
		myResponse.setAmount(amount);
		myResponse.setTerm(term);
		myResponse.setEmail(email);
		myResponse.setCreditScore(creditScore);

		
		if (creditScore < iciciCreditScore) {
			myResponse.setInterest(0.0);
			myResponse.setEMI(0.0);
			myResponse.setStatus("Your are not eligible for loan with ICICI due to low credit score");
		} else {
			emi = bankUtil.calculateEMI(amount, term, iciciInterest);
			
			myResponse.setInterest(iciciInterest);
			myResponse.setEMI(emi);
			myResponse.setStatus("Congratulations, your loan can be processed with ICICI");
		}
		
		System.out.println("ICICI Response sent : Input Parameters are :: Name = " +name+ " ,SSN = " +ssn+ " ,"
				+ "amount = " +amount+ " ,term = " +term+ " ,email = " +email+ " ,creditscore = " +creditScore+ " ,EMI = " +emi+ " ,interest = " +iciciInterest);
		
		return myResponse;
	}
	
}
