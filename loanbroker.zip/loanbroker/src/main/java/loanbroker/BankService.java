package loanbroker;

public class BankService {

	double interest = 9.4;
	
	public String getLoanStatus(Customer customer) {

		String name = customer.getName();
		int ssn = customer.getSsn();
		Long amount = customer.getAmount();
		int term = customer.getTerm();
		String email = customer.getEmail();
		int creditScore = customer.getCreditScore();
		
		if (creditScore < 800) {
			return "Loan Cannot be processed due to low credit score";
		} else {
			double emi = calculateEMI(amount, term);
			String result = "Congratulations, your loan can be processed with ICICI with rate of "
					+ "interest : " + interest + " AND EMI of Rs. " + emi + " per month";
			return result;
		}
	}
	
	private double calculateEMI(Long amount, int term) {
		double finalRate = interest/1200;
		double emi = (amount * finalRate *(Math.pow((1 + finalRate), term)) / ((Math.pow((1 + finalRate), term)) - 1));
		return emi;
	}
	
}
