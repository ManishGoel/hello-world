package manish.model;

import java.util.Date;

public class soapserviceclient {

	public String getMyDetails(Customer customer) {
		String myName = customer.getName();
		Date myDate = customer.getDob();
		
		int age = calculateAge(myDate);
		return "Dear " + myName + " You are " + age + " Years old !!!!";
	}

	private int calculateAge(Date myDate) {
		int dobYear = myDate.getYear();
		Date date = new Date();
		int currYear = date.getYear();
		
		int diff = currYear - dobYear;
		
		return diff;
		
	}
}
