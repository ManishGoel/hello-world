package manish.model;

import java.io.Serializable;
import java.util.Date;

public class Customer implements Serializable{

	private static final long serialVersionUID = 4622840173638021051L;
	
	private String name;
	private Date dob;
	
	public Customer() {
		super();
	}
	
	public Customer(String name, Date dob) {
		this.name = name;
		this.dob = dob;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}

	

}
