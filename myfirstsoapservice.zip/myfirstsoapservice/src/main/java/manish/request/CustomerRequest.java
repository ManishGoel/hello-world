package manish.request;

import java.io.Serializable;

import manish.model.Customer;



public class CustomerRequest implements Serializable{

	private static final long serialVersionUID = 6365612435470800746L;
	
	private Customer customer;
	
	private int creditScore;

	public CustomerRequest() {
		super();
	}

	public CustomerRequest(Customer customer, int creditScore) {
		this.customer = customer;
		this.creditScore = creditScore;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getCreditScore() {
		return creditScore;
	}

	public void setCreditScore(int creditScore) {
		this.creditScore = creditScore;
	}
	
	
}
