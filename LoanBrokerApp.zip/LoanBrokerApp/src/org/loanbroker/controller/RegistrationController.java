package org.loanbroker.controller;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.loanbroker.form.*;

/**
 * Servlet implementation class UserDataServlet
 */
@Controller
@SessionAttributes("command")
public class RegistrationController {
	private static final long serialVersionUID = 1L;
	private String output = null;

    @RequestMapping(value = "/welcome", method = RequestMethod.GET)
    public ModelAndView welcome() {
    	return new ModelAndView("welcome", "command", new LoanData());
    }
	
    @RequestMapping(value = "/registration", method = RequestMethod.GET)
    public ModelAndView registration() {
    	return new ModelAndView("registration", "command", new LoanData());
    }
    
    @RequestMapping(value = "/findLoan", method = RequestMethod.POST)
    public String addRegistration(@Valid @ModelAttribute("command") LoanData loanData, BindingResult bindingResult, ModelMap model) throws IOException {
    	
    	String serviceResp = null;
    	String fullName = loanData.getFullname();
    	String ssn = loanData.getSsn();
    	String amount = loanData.getAmount();
    	String term = loanData.getTerm();
    	String email = loanData.getEmail();
    	String salary = loanData.getSalary();
    	String bank = loanData.getBank();
    	
    	if (bindingResult.hasErrors())
    		return "registration";
    	
    	URL url = new URL("http://192.168.1.2:8185/sbi/sbirequest?name=" +fullName+ "&ssn=" +ssn+
    			"&amount=" +amount+ "&term=" +term+ 
    			"&email=" +email+ "&creditScore=" +salary);
    	HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Accept", "application/json");
		
		if (conn.getResponseCode() != 200) {
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
		}
		
		BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
		System.out.println("Output from Server .... \n");
		while ((output = br.readLine()) != null) {
			serviceResp = output;
			System.out.println(output);
		}
    	conn.disconnect();
    	
    	model.addAttribute("fullname", loanData.getFullname());
    	model.addAttribute("ssn", loanData.getSsn());
    	model.addAttribute("amount", loanData.getAmount());
    	model.addAttribute("term", loanData.getTerm());
    	model.addAttribute("email", loanData.getEmail());
    	model.addAttribute("salary", loanData.getSalary());
    	model.addAttribute("bank", loanData.getBank());
    	return "result";
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	/*protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		if (request.getParameter("getQuote") != null) {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String name = request.getParameter("name");
		String ssn = request.getParameter("ssn");
		String amount = request.getParameter("amount");
		String term = request.getParameter("term");
		String email = request.getParameter("email");
		String salary = request.getParameter("salary");
		String bank = request.getParameter("bank");
		String serviceResp = null;
		ArrayList description = new ArrayList();
		ArrayList emi = new ArrayList();
		ArrayList roi = new ArrayList();
		ArrayList bankName = new ArrayList();
		
		
		session.setAttribute("retValue", "manish");
		
		//http://10.103.0.123:8080/loanbroker?name=gaurav&ssn=12&amount=12000000&term=90&email=as.gmail.com&salary=909&bank=all
		//URL url = new URL("http://10.102.8.21:8185/sbi/sbirequest?name=" +name+ "&ssn=" +ssn+ "&amount=" +amount+ "&term=" +term+ "&email=" +email+ "&creditScore=" +creditscore);
		URL url = new URL("http://10.103.0.145:8080/loanbroker?name=" +name+ "&ssn=" +ssn+ "&amount=" +amount+ "&term=" +term+ "&email=" +email+ "&salary=" +salary+ "&bank="+bank);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Accept", "application/json");
		
		if (conn.getResponseCode() != 200) {
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
		}
		
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));
		
		System.out.println("Output from Server .... \n");
		while ((output = br.readLine()) != null) {
			serviceResp = output;
			System.out.println(output);
		}

		JSONObject obj;
		JSONArray myArray;
		JSONArray finalArray = null;
		JSONObject finalobj = null;
		try {
			obj = new JSONObject(serviceResp);
			myArray = obj.names();
			for (int i = 0; i < myArray.length(); i++) {
				String myName = myArray.getString(i);
				if (myName.equalsIgnoreCase("bankResponse") && bank.equalsIgnoreCase("all"))
					finalArray = obj.getJSONArray("bankResponse");
				else if (!bank.equalsIgnoreCase("all"))
					finalobj = obj.getJSONObject("bankResponse");
					
			}
			
			if (null != finalArray && finalArray.length() != 0) {
			for (int i = 0; i < finalArray.length(); i++)
			{
				description.add(i, finalArray.getJSONObject(i).getString("desc"));
				emi.add(i, finalArray.getJSONObject(i).getString("emi"));
				roi.add(i, finalArray.getJSONObject(i).getDouble("roi"));
				bankName.add(i, finalArray.getJSONObject(i).getString("bankName"));
			}
			} else if (null != finalobj && finalobj.length() != 0) {
				description.add(0, finalobj.getString("desc"));
				emi.add(0, finalobj.getString("emi"));
				roi.add(0, finalobj.getDouble("roi"));
				bankName.add(0, finalobj.getString("bankName"));
			}
			else {
				Object myObj = obj.get("code");
				if (myObj.toString().equalsIgnoreCase("500")) {
					session.setAttribute("servCode", obj.get("code").toString());
					session.setAttribute("servResp", obj.get("desc").toString());
				}
			}
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		conn.disconnect();
		
		
		if(name.isEmpty()||ssn.isEmpty()||amount.isEmpty()||term.isEmpty()||email.isEmpty()||salary.isEmpty())
		{
			RequestDispatcher rd = request.getRequestDispatcher("registration.jsp");
			out.println("<font color=red>Please fill all the fields</font>");
			rd.include(request, response);
		}
		else
		{
			RequestDispatcher rd = request.getRequestDispatcher("registration.jsp");
			process(request, response);
			request.setAttribute("description", description);
			request.setAttribute("emi", emi);
			request.setAttribute("roi", roi);
			request.setAttribute("bankName", bankName);
			
			System.out.println(request.getAttribute("description"));
			System.out.println(request.getAttribute("emi"));
			System.out.println(request.getAttribute("roi"));
			System.out.println(request.getAttribute("bankName"));
			rd.forward(request, response);
		}
		} else if (request.getParameter("getElig") != null){
			System.out.println("Hello Manish");
			session.setAttribute("quoteButton", "true");
			RequestDispatcher rd = request.getRequestDispatcher("registration.jsp");
			rd.forward(request, response);
		}
	}
	
	
	private void process(HttpServletRequest request,
	        HttpServletResponse response) {
	    storeInRequest(request, "name");
	    storeInRequest(request, "ssn");
	    storeInRequest(request, "amount");
	    storeInRequest(request, "term");
	    storeInRequest(request, "email");
	    storeInRequest(request, "salary");

	}

	private void storeInRequest(HttpServletRequest request,String param){
	    String val =  request.getParameter(param);
	    if(param!=null && !param.isEmpty()){
	        System.out.println(val);
	        request.setAttribute(param, val);
	    }
	}*/

}
